package com.example.numbers_kotlin

data class Trivia(
 var text: String,
 var number: Int,
 var found: Boolean,
 var type: String
)
